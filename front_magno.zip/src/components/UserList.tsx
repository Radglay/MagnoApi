import React, {useState, useEffect} from "react";
import axios from "axios";
import UserService from "../services/UserService";
import IUser from "./IUser";


//props are not necessary 
export default function UserList(): JSX.Element {
    const [userList, setUserList] = useState<IUser[]>([]);
    const [searcherTerm, setSearcherTerm] = useState<string>("");
    const [inputUser, setInputUser] = useState<IUser>({
        name: "",
        surname: "",
        age: 0
    });

    //const [inputUser, setInputUser] = useState<IUser>()

    useEffect(() => {
        UserService.getUserList().then((res) => {
            setUserList(res);
        }).catch((err) => console.log(err));
    }, []);

    useEffect(() => {
        console.log(userList);
    }, [userList]);
    //at the site realoading

    return (
        <div>
            <h1>User List</h1>
           
            <input className="searcher" onChange={event => setSearcherTerm(event.target.value)}/>
            <button onClick={() => {UserService.getUserById(searcherTerm).then((res) => {
                setUserList([res]);
            }).catch((err) => console.log(err));
            }}>Find user</button>
            
            <table className="user-table">
                <thead>
                    <tr>
                    <td>User id</td>
                    <td>User name</td>
                    <td>User surname</td>
                    <td>User age</td>
                    </tr>
                </thead>
                <tbody>
                    {userList.map(user => (
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.surname}</td>
                                <td>{user.age.toString()}</td>
                            </tr>
                    ))}
                </tbody>
            </table>
            
             <button onClick={() => UserService.getUserList().then((res) => {
                setUserList(res);
             }).catch((err) => console.log(err))}>Clear</button>
            
            <h1>Create new User</h1>
            <label>Name: <input className="name" onChange={(event) => {
                setInputUser({
                    name: event.target.value,
                    surname: inputUser.surname,
                    age: inputUser.age
                })
            }}></input></label>
            <br/>
            <label>Surname: <input className="surname" onChange={(event) => {
                setInputUser({
                    name: inputUser.name,
                    surname: event.target.value,
                    age: inputUser.age
                })
            }}></input></label>
            <br/>
            <label>Age: <input className="age" onChange={(event) => {
                setInputUser({
                    name: inputUser.name,
                    surname: inputUser.surname,
                    age: Number(event.target.value)
                })
            }}></input></label>
            <br/>
            <button onClick={() => UserService.addUser(inputUser).then((res) => {
                console.log(res);
                UserService.getUserList().then((res) => {
                    setUserList(res);
                }).catch((err) => console.log(err));
            }).catch((err) => console.log(err))
            }>Create</button>
        </div>
    );
}