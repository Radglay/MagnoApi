export default interface IUser {
    id?: string,
    name: string,
    surname: string,
    age: Number,
    description?: string
}
