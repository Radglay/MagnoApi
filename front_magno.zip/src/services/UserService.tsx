import axios from 'axios';
import IUser from "../components/IUser";

//1)
const BASE_URL = "http://localhost:8080/api/users/"; //#todo import from config file.. or store it here?

//2)
// const instance = axios.create({
//     baseURL: BASE_URL
// })

export default {
    // getUserList: function():  {
    //     axios.get(BASE_URL + "/api/users")
    //     .then((res) => {
    //         return res.data;
    //     })
    //     .catch((err) => console.log(err));
    // },

  
    getUserList: async function() {
        try {
            const response = await axios.get(BASE_URL);
            return response.data;
        } catch (err) {
            throw err;
        }
    },
    getUserById: async function(id: string) {
        try {
            const response = await axios.get(BASE_URL + id);
            return response.data;
        } catch (err) {
            throw err;
        }
    },
    addUser: async function(inputUser: IUser) {
        try {
            const response = await axios.post(BASE_URL, 
                JSON.stringify(inputUser), {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
            return response.data
        } catch (err) {
            throw err;
        }
    }
}